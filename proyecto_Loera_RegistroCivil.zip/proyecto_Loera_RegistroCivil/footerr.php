<footer>
		<div class="wrapp">
            <p> 20 Noel Loera  </p>
            <p> // SUBMÓDULO 2
                Desarrolla aplicaciones Web con conexión a bases de datos</p>
            <p>https://github.com/jaramillo041104 </p>
		</div>
	</footer>